---
name: Tam Linh Huong Sac
colors:
  surface: '#FFFFFF'
  surface-dim: '#e9d7c8'
  surface-bright: '#fff8f5'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#fff1e8'
  surface-container: '#feeadc'
  surface-container-high: '#f8e5d6'
  surface-container-highest: '#f2dfd1'
  on-surface: '#231a11'
  on-surface-variant: '#58413f'
  inverse-surface: '#392e25'
  inverse-on-surface: '#ffeee1'
  outline: '#8b716e'
  outline-variant: '#dfbfbc'
  surface-tint: '#aa3531'
  primary: '#6a020a'
  on-primary: '#ffffff'
  primary-container: '#8b1e1e'
  on-primary-container: '#ff9d95'
  inverse-primary: '#ffb3ad'
  secondary: '#7e5700'
  on-secondary: '#ffffff'
  secondary-container: '#fdc668'
  on-secondary-container: '#765100'
  tertiary: '#00345a'
  on-tertiary: '#ffffff'
  tertiary-container: '#194b77'
  on-tertiary-container: '#90bbee'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdad6'
  primary-fixed-dim: '#ffb3ad'
  on-primary-fixed: '#410003'
  on-primary-fixed-variant: '#891c1d'
  secondary-fixed: '#ffdead'
  secondary-fixed-dim: '#f4bd61'
  on-secondary-fixed: '#281900'
  on-secondary-fixed-variant: '#604100'
  tertiary-fixed: '#d1e4ff'
  tertiary-fixed-dim: '#9fcafd'
  on-tertiary-fixed: '#001d35'
  on-tertiary-fixed-variant: '#164975'
  background: '#fff8f5'
  on-background: '#231a11'
  surface-variant: '#f2dfd1'
  primary-hover: '#6F1717'
  bg-page: '#FBF6EC'
  surface-alt: '#F3EAD8'
  text-primary: '#2B2118'
  text-muted: '#6B5E50'
  border-subtle: '#E3D6BF'
  region-bac: '#2F5D8A'
  region-trung: '#8A5A2F'
  region-nam: '#2F7A5A'
  status-success: '#2E7D4F'
  status-warning: '#B7791F'
  status-danger: '#B42318'
typography:
  display-hero:
    fontFamily: Playfair Display
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.01em
  display-hero-mobile:
    fontFamily: Playfair Display
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Playfair Display
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
  headline-lg-mobile:
    fontFamily: Playfair Display
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-md:
    fontFamily: Playfair Display
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 30px
  headline-sm:
    fontFamily: Playfair Display
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
  body-lg:
    fontFamily: Be Vietnam Pro
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Be Vietnam Pro
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
  body-sm:
    fontFamily: Be Vietnam Pro
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Be Vietnam Pro
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Be Vietnam Pro
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.04em
  lunar-date:
    fontFamily: Be Vietnam Pro
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-desktop: 1.5rem
  space-2xs: 0.25rem
  space-xs: 0.5rem
  space-sm: 0.75rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
  space-2xl: 3rem
  space-3xl: 4rem
---

## Brand & Style

### Brand Personality & Emotional Architecture
The design system bridges Vietnamese ritual heritage with contemporary utilitarian e-commerce. It evokes dignity, reverence, warmth, and filial devotion (*hiếu kính*), entirely stripped of superstition, visual clutter, or fear-based religious tropes. The interface instills calm confidence and mental clarity for users honoring ancestral rites, ensuring ritual preparations feel orderly, respectful, and serene.

### Visual Style: Neo-Traditional Editorial Minimalism
- **Atmospheric Palette:** Warm parchment and lacquered vermilion ground the visual hierarchy, establishing the dignity of temple wooden architecture and silk paper scrolls without sensory fatigue.
- **Harmonious Accents:** Aged metallic gold and deep cerulean accents introduce sacred structural points while maintaining breathing room.
- **Subtle Cultural Ornamentation:** Restrained hairline dividing lines, serene lotus curvature motifs used sparingly as subtle background masks, and structured editorial typestyles reflect heritage craftsmanship.
- **Universal Accessibility:** Accommodates intergenerational users with large touch targets, high contrast, and non-reliance on color alone for critical status indication.

## Colors

### Color Philosophy & Distribution
- **Primary (`#8B1E1E` - Do Tram):** Represents ceremonial lacquer, sacrificial incense, and auspicious solemnity. Used for major calls-to-action, active navigational states, and key anchors.
- **Secondary / Accent (`#C8963E` - Vang Dong):** Represents polished bronze incense burners, antique brass bells, and ritual reverence. Deployed for celebration badges, highlights, and focus borders.
- **Background & Canvas:**
  - `#FBF6EC` (Nen Kem): Natural parchment canvas preventing harsh eye strain.
  - `#FFFFFF` (Surface): Clean cards, elevated modals, and product presentation stages.
  - `#F3EAD8` (Surface Alt): Secondary panels, highlighted lunar calendar dates, and regional switchers.
- **Typography & Neutrals:**
  - `#2B2118` (Nau Den Dam): Deep woodcut pigment for crisp readability.
  - `#6B5E50` (Nau Dat Diu): Earthy secondary tone for supplemental descriptions and calendar subtitles.
  - `#E3D6BF` (Vien Giay Gio): Hairstyle borders framing modular cards.

### Regional Identifiers (Ba Mien)
- **Mien Bac (`#2F5D8A`):** Classic indigo-slate reflecting northern scholarly traditions and seasonal coolness.
- **Mien Trung (`#8A5A2F`):** Terracotta ochre referencing imperial Hue brickwork and Central coast soil.
- **Mien Nam (`#2F7A5A`):** Lush fertile jade green evoking Southern delta abundance.

## Typography

### Font Selection & Pairing Hierarchy
- **Editorial Headings (`Playfair Display`):** Classical, high-contrast serif expressing Vietnamese literary tradition, ritual gravitas, and reverence across large titles and ceremony names.
- **System Interface & Body (`Be Vietnam Pro`):** Engineered natively for Vietnamese diacritics with balanced tone marks (*dấu*), ensuring tall line-height buffers that prevent diacritic clipping on complex terms like *cúng, giỗ, lễ, nguyện*.

### Typographic Safeguards
- Body text never scales below `16px` for standard reading views to serve older family heads managing ritual dates.
- Long passages of italicized serif are banned to avoid visual degradation on lower-density mobile screens.
- All calendar cells pair modern Gregorian numbers with legible muted Lunar indicators (`d/m` notation on the first and fifteenth of lunar months).

## Layout & Spacing

### Layout Structure
- **Fluid Multi-Device Grid:** Built upon a 4-column framework for mobile viewport (`<640px`), expanding to 8 columns for tablet (`640px-1023px`), and 12 columns for desktop (`≥1024px`).
- **Max Canvas Width:** Bound to a maximum content container of `1200px` centered with variable margins: `16px` on mobile screens, expanding to `24px` on desktop monitors.

### Spacing Scale
A strict 4px/8px modular rhythm guarantees structural order across ceremonial calendars, step-by-step offerings checklists, and checkout forms:
- `space-2xs` (4px): Fine marker spacing, badge internal padding, and checkbox gap.
- `space-xs` (8px): Icon and text pairings, stepper button padding.
- `space-sm` (12px): Input field internal vertical padding, dense card metadata.
- `space-md` (16px): Standard form element gap, mobile container margin, checklist row padding.
- `space-lg` (24px): Standard card interior padding, grid gutters on desktop.
- `space-xl` (32px): Major subsection gaps, modal interior padding.
- `space-2xl` (48px): Page section separators on mobile.
- `space-3xl` (64px): Hero block breathing space, desktop section transitions.

## Elevation & Depth

### Depth Philosophy
The design avoids deep, artificial dropped shadows or harsh neon drop spreads, relying instead on warm ambient paper layering, subtle tactile boundaries, and gentle warm-tinted shading.

### Layering Levels
- **Ground Floor (Canvas):** Tone `#FBF6EC` acts as the unpolished parchment base layer.
- **Tier 1 (Surface Neutral):** Tone `#F3EAD8` used for secondary groupings, calendar controls, and table header rows with no cast shadows.
- **Tier 2 (Elevated Cards & Containers):** Pure `#FFFFFF` cards resting on the parchment canvas. Surface definition is reinforced by a crisp hairline border (`#E3D6BF`, 1px solid) complemented by an ambient warm shadow: `0 2px 8px rgba(43, 33, 24, 0.08)`.
- **Tier 3 (Floating Controls & Navigation):** Fixed 64px header and mobile bottom bar feature backdrop blur (`backdrop-filter: blur(8px)`) paired with `rgba(251, 246, 236, 0.92)` tinting and a bottom border `1px solid #E3D6BF`.
- **Tier 4 (Overlays & Modals):** Dropdown menus, bottom drawers, and modal dialogs use elevated ambient depth: `0 12px 32px rgba(43, 33, 24, 0.16)` with full backdrop scrim `rgba(43, 33, 24, 0.5)`.

### Interactive Feedback
Interactive cards rise smoothly by `translateY(-2px)` on hover while the shadow deepens subtly to `0 6px 16px rgba(43, 33, 24, 0.12)`, offering calm, physical acknowledgment.

## Shapes

### Corner Curvature Language
The system adopts an intentional, harmonious roundedness level (`2`) calibrated specifically for tactile elegance:
- **Cards & Dialog Containers:** Defined with `12px` (`rounded-xl` equivalent within this scale) to preserve a tailored, card-like feel.
- **Interactive Controls (Buttons, Inputs, Selectors):** Set strictly to `10px` (`rounded-lg`), creating a grounded silhouette that remains inviting to touch.
- **Badges, Counter Pills, & Indicators:** Set to fully rounded `999px` (`rounded-full`) to contrast against structural rectilinear grids.
- **Calendar Day Matrix:** Bounded within square or subtle `8px` rounded cells to facilitate clean multi-row alignment.

## Components

### Buttons
- **Touch Target:** Minimum height of `44px` across mobile and desktop.
- **Primary:** Background `#8B1E1E`, Text `#FFFFFF`, font weight 600, border radius `10px`. Hover: `#6F1717`. Active focus: 2px ring offset `#C8963E`.
- **Outline / Secondary:** Background transparent, border `1.5px solid #8B1E1E`, text `#8B1E1E`. Hover: Background `#F3EAD8`.
- **Ghost:** Text `#6B5E50`. Hover: Background `#F3EAD8`, Text `#2B2118`.
- **Danger:** Background `#B42318`, Text `#FFFFFF`. Hover: `#8C1B13`.

### Form Fields & Inputs
- **Text Inputs, Select, Textareas:** Height `44px`, background `#FFFFFF`, border `1px solid #E3D6BF`, border radius `10px`, typography `Be Vietnam Pro` 16px, text `#2B2118`.
- **Focus State:** Border color `#8B1E1E` with subtle glow ring `0 0 0 3px rgba(200, 150, 62, 0.25)`.
- **Error State:** Border color `#B42318`, assistive helper copy rendered in `status-danger` (`#B42318`) with linked ARIA descriptors.
- **Labels:** Persistent, never floating inside input placeholders, rendered in `#2B2118` font size 14px, weight 600.

### Checkboxes & Checklists (Ritual Offerings)
- **Checkboxes:** Size `22px x 22px` for comfortable thumb interaction on mobile devices.
- **Checked State:** Background `#8B1E1E`, border `#8B1E1E`, checkmark icon in `#FFFFFF`.
- **Checklist Item Row:** Card or strip container with `12px` vertical padding, border bottom `1px solid #E3D6BF`. Hover highlights background with `#F3EAD8`. Checked items strike through item name and lower text opacity to `#6B5E50`.

### Cards & Surfaces
- **Product Card:** Surface `#FFFFFF`, border `1px solid #E3D6BF`, radius `12px`, padding `16px`. Aspect ratio for images 1:1 with soft rounded corners `8px`. Includes 2-line clamped product title and bold pricing in `#8B1E1E`.
- **Holiday & Memorial Card:** Surface `#FFFFFF`, border `1px solid #E3D6BF`, top border accent line `3px solid #C8963E` for major festivals (*Đại Lễ*).

### Badges & Chips
- **Geometry:** Height `24px`, horizontal padding `10px`, border radius `999px`, font size `12px`, font weight 600.
- **Region Bắc:** Background `rgba(47, 93, 138, 0.12)`, text `#2F5D8A`, border `1px solid rgba(47, 93, 138, 0.25)`.
- **Region Trung:** Background `rgba(138, 90, 47, 0.12)`, text `#8A5A2F`, border `1px solid rgba(138, 90, 47, 0.25)`.
- **Region Nam:** Background `rgba(47, 122, 90, 0.12)`, text `#2F7A5A`, border `1px solid rgba(47, 122, 90, 0.25)`.
- **Festivals / Major Rituals:** Background `rgba(200, 150, 62, 0.16)`, text `#8B1E1E`, border `1px solid #C8963E`.

### Region Switcher (Segmented Control)
- Continuous pill or segmented track (`#F3EAD8`), inner items radius `8px`. Active segment: Surface `#FFFFFF`, text color matching regional token, subtle drop shadow `0 1px 3px rgba(43,33,24,0.1)`.

### Calendar Grid & Day Cells
- **Grid Layout:** 7-column uniform display starting with Thứ Hai (Monday).
- **Day Cell:** Min-height `56px` on mobile, `84px` on desktop. Primary solar date prominent (18px, `#2B2118`), lunar date small in bottom corner (11px, `#6B5E50`).
- **Today Marker:** Highlighted with a `2px solid #8B1E1E` border.
- **Selected State:** Background `#F3EAD8`.
- **Dots / Indicators:**
  - Gold dot (`#C8963E`): Major traditional festival (*Lễ Lớn*).
  - Red dot (`#8B1E1E`): Mùng 1 & Rằm (New Moon / Full Moon).
  - Blue dot (`#2F5D8A`): Family Memorial (*Ngày Giỗ Gia Đình*).