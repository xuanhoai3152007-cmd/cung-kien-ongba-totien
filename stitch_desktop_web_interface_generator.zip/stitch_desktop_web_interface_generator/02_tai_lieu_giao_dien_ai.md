# 02 – TÀI LIỆU GIAO DIỆN (DÀNH CHO AI THỰC THI)

> Dự án: **cungkientamlinh** – website lịch cúng kiến & đặt đồ cúng.
> Đọc kèm: `01-tai-lieu-nghiep-vu.md`. File này mô tả **giao diện cần dựng**; AI phải bám sát, không tự ý thêm/bớt trang.
> Stack UI: React + TypeScript + Tailwind CSS + shadcn/ui (hoặc Radix) + lucide-react.

---

## 0. Quy tắc cho AI khi dựng giao diện
1. **Mobile-first**: thiết kế cho 360px trước, rồi mở rộng 768px, 1280px.
2. Dùng **design token** (mục 1) qua CSS variables/Tailwind theme, **không hard-code màu** trong component.
3. Mọi chữ hiển thị bằng **tiếng Việt**, tách vào file `i18n/vi.ts` (không rải chuỗi trong JSX).
4. Mỗi component có đủ **4 trạng thái**: loading (skeleton), empty, error, success.
5. Chữ tối thiểu 16px body, nút tối thiểu cao 44px (người lớn tuổi dùng mobile).
6. Không dùng ảnh nền chữ; ảnh có `alt` tiếng Việt.
7. Không dùng emoji tôn giáo gây phản cảm; icon dùng lucide (nhang `Flame`, hoa `Flower2`, lịch `CalendarDays`, giỏ `ShoppingBasket`, user `User`).
8. Nội dung tín ngưỡng trình bày **trang trọng, trung tính**.

---

## 1. Design tokens

### 1.1 Màu (light mode; không cần dark mode ở MVP)
| Token | Giá trị | Dùng cho |
|---|---|---|
| `--color-primary` | `#8B1E1E` (đỏ trầm) | Nút chính, link nhấn, tiêu đề phụ |
| `--color-primary-hover` | `#6F1717` | Hover nút chính |
| `--color-accent` | `#C8963E` (vàng đồng) | Điểm nhấn, badge lễ lớn, đường viền trang trí |
| `--color-bg` | `#FBF6EC` (kem) | Nền trang |
| `--color-surface` | `#FFFFFF` | Card, modal |
| `--color-surface-alt` | `#F3EAD8` | Khối phụ, ô lịch cuối tuần |
| `--color-text` | `#2B2118` | Chữ chính |
| `--color-text-muted` | `#6B5E50` | Chữ phụ |
| `--color-border` | `#E3D6BF` | Viền |
| `--color-success` | `#2E7D4F` | Đã chuẩn bị / hoàn thành |
| `--color-warning` | `#B7791F` | Chờ xử lý |
| `--color-danger` | `#B42318` | Lỗi / huỷ |
| `--color-region-bac` | `#2F5D8A` | Nhãn miền Bắc |
| `--color-region-trung` | `#8A5A2F` | Nhãn miền Trung |
| `--color-region-nam` | `#2F7A5A` | Nhãn miền Nam |

Độ tương phản chữ/nền ≥ 4.5:1.

### 1.2 Typography
- Tiêu đề: **"Be Vietnam Pro"** hoặc **"Playfair Display"** (có hỗ trợ tiếng Việt) – chọn 1 và dùng thống nhất. Gợi ý: tiêu đề `Playfair Display`, nội dung `Be Vietnam Pro`.
- Cỡ: h1 28/36 (mobile) – 40/48 (desktop); h2 22/30; h3 18/26; body 16/26; small 14/20.
- Không dùng chữ in nghiêng dài; không dưới 14px.

### 1.3 Khoảng cách, bo góc, bóng
- Spacing thang 4px (4, 8, 12, 16, 24, 32, 48, 64).
- Bo góc: card `12px`, nút `10px`, input `10px`, badge `999px`.
- Bóng nhẹ: `0 2px 8px rgba(43,33,24,.08)`.
- Container tối đa `1200px`, padding ngang 16px (mobile) / 24px (desktop).

### 1.4 Họa tiết (tuỳ chọn, nhẹ nhàng)
- Viền vàng đồng mảnh ở đầu trang chi tiết lễ; hoa văn cánh sen SVG mờ ở hero. Không làm rối mắt.

---

## 2. Layout chung

### 2.1 Header (cố định, cao 64px)
- Trái: logo + tên "Cúng Kiến Tâm Linh".
- Giữa (desktop): menu `Lịch cúng` · `Ngày lễ` · `Cửa hàng` · `Hướng dẫn`.
- Phải: ô tìm kiếm (icon), **giỏ hàng** (badge số lượng), **tài khoản** (chưa đăng nhập: nút `Đăng nhập`; đã đăng nhập: avatar + dropdown `Hồ sơ`, `Đơn hàng`, `Ngày giỗ`, `Đăng xuất`).
- Mobile: hamburger mở drawer; **thanh điều hướng dưới** 4 mục: Lịch · Cửa hàng · Giỏ · Tôi.

### 2.2 Bộ chọn vùng miền (Region Switcher)
- Segmented control 3 nút: `Bắc` · `Trung` · `Nam` (+ `Tất cả`). Màu nhãn theo token vùng.
- Hiển thị trên trang Lịch/Chi tiết lễ/Cửa hàng; lưu lựa chọn vào hồ sơ (nếu đã đăng nhập) hoặc localStorage.

### 2.3 Footer
- Giới thiệu ngắn, liên hệ, chính sách giao hàng/đổi trả, điều khoản, mạng xã hội.

---

## 3. Danh sách trang (Routes công khai & người dùng)

| # | Route | Tên trang | Truy cập |
|---|---|---|---|
| 1 | `/` | Trang chủ | Công khai |
| 2 | `/lich` | Lịch cúng (tháng) | Công khai |
| 3 | `/le/:slug` | Chi tiết ngày lễ | Công khai |
| 4 | `/cua-hang` | Danh sách sản phẩm | Công khai |
| 5 | `/cua-hang/:slug` | Chi tiết sản phẩm | Công khai |
| 6 | `/gio-hang` | Giỏ hàng | Công khai |
| 7 | `/thanh-toan` | Thanh toán | Đăng nhập |
| 8 | `/don-hang` | Lịch sử đơn | Đăng nhập |
| 9 | `/don-hang/:id` | Chi tiết đơn | Đăng nhập |
| 10 | `/ngay-gio` | Ngày giỗ của tôi | Đăng nhập |
| 11 | `/ho-so` | Hồ sơ & địa chỉ & nhắc lịch | Đăng nhập |
| 12 | `/dang-nhap` | Đăng nhập | Khách |
| 13 | `/dang-ky` | Đăng ký | Khách |
| 14 | `/quen-mat-khau`, `/dat-lai-mat-khau` | Khôi phục | Khách |
| 15 | `/huong-dan`, `/huong-dan/:slug` | Bài hướng dẫn/văn khấn | Công khai |
| 16 | `*` | 404 | – |

---

## 4. Mô tả từng trang

### 4.1 Trang chủ `/`
Thứ tự khối (từ trên xuống):
1. **Hero**: tiêu đề "Chuẩn bị lễ chu đáo, tâm an ý thành"; mô tả 1 dòng; 2 nút `Xem lịch cúng` (primary), `Mua đồ cúng` (outline).
2. **Hôm nay**: card hiển thị ngày dương + âm, tên ngày lễ (nếu có) hoặc "Hôm nay không có lễ lớn", nút `Xem cần chuẩn bị`.
3. **Sắp tới** (5 lễ gần nhất): thẻ ngang cuộn được, mỗi thẻ: ngày dương/âm, tên lễ, còn X ngày, nút `Chuẩn bị`.
4. **Chọn vùng miền**: 3 thẻ lớn Bắc/Trung/Nam, mô tả 1 dòng đặc trưng, bấm để đặt vùng.
5. **Bộ lễ nổi bật**: carousel combo (ảnh, tên, giá, nút `Thêm vào giỏ`).
6. **Danh mục sản phẩm**: lưới 6 ô icon (nhang, đèn nến, giấy tiền vàng mã, hoa, trái cây, bộ lễ).
7. **Cách hoạt động**: 3 bước (Xem lịch → Chọn đồ → Giao tận nhà).
8. **Bài hướng dẫn mới**: 3 thẻ.

### 4.2 Lịch cúng `/lich`
- Thanh trên: `‹` Tháng/Năm `›`, nút `Hôm nay`, bộ lọc (Tất cả/Hàng tháng/Lễ lớn/Giỏ của tôi), Region Switcher.
- **Lưới tháng 7 cột** (T2 → CN):
  - Mỗi ô: số dương (to), số âm (nhỏ, góc dưới; hiển thị `d/m` khi mùng 1), chấm màu: vàng = lễ lớn, đỏ = mùng 1/rằm, xanh dương = giỗ của tôi.
  - Ô hôm nay: viền đỏ đậm. Ô được chọn: nền `surface-alt`.
- Dưới lưới (mobile) / cột phải (desktop): **Danh sách lễ trong tháng** (ngày, tên, nhãn vùng nếu lễ có khác biệt).
- Bấm ô có lễ → mở **panel/Bottom sheet** tóm tắt: tên lễ, ngày âm, 3 vật phẩm chính, nút `Xem chi tiết`, `Thêm bộ lễ vào giỏ`.
- Trạng thái: loading skeleton lưới; lỗi hiển thị nút `Thử lại`.

### 4.3 Chi tiết ngày lễ `/le/:slug`
Bố cục 2 cột desktop (nội dung 2/3, sidebar 1/3); 1 cột mobile.
1. **Tiêu đề lễ** + ngày dương/âm của **lần tới** + đếm ngược "Còn X ngày".
2. **Region Switcher** (tab) – đổi nội dung bên dưới.
3. **Ý nghĩa** (đoạn ngắn, mở rộng được).
4. **Checklist chuẩn bị** (cốt lõi):
   - Nhóm: Lễ chay/mặn, Hương – đèn, Vàng mã, Hoa – quả, Khác.
   - Mỗi dòng: checkbox, tên vật phẩm, số lượng gợi ý, ghi chú nhỏ, nhãn vùng (nếu riêng vùng), nút `Mua` nếu có sản phẩm liên kết (hiển thị giá).
   - Chưa đăng nhập: checkbox hoạt động tạm (local), có dòng "Đăng nhập để lưu checklist".
   - Thanh tiến độ "Đã chuẩn bị 5/12".
5. **Cách bày mâm** & **Lưu ý** (cảnh báo tuỳ phong tục).
6. **Văn khấn tóm tắt** (accordion, có ghi chú "mang tính tham khảo").
7. **Sidebar sticky**: card "Bộ lễ gợi ý" (combo theo vùng) với nút `Thêm cả bộ vào giỏ` + tổng tiền.
8. Chia sẻ (copy link), In checklist (`window.print` với style in gọn).

### 4.4 Cửa hàng `/cua-hang`
- Sidebar lọc (desktop) / Drawer lọc (mobile): danh mục, khoảng giá, **vùng miền**, **ngày lễ phù hợp**, còn hàng.
- Sắp xếp: Nổi bật, Giá tăng/giảm, Mới nhất.
- Lưới sản phẩm: 2 cột mobile, 3–4 cột desktop. **ProductCard**: ảnh vuông, nhãn (Hot/Theo mùa/Miền…), tên (2 dòng), giá, đơn vị, nút `Thêm vào giỏ`.
- Phân trang hoặc "Xem thêm" (12 sp/lần). Ô tìm kiếm có gợi ý.

### 4.5 Chi tiết sản phẩm `/cua-hang/:slug`
- Gallery ảnh (swipe mobile), tên, giá, đơn vị, tình trạng kho.
- Chọn số lượng (stepper), nút `Thêm vào giỏ` (primary), `Mua ngay`.
- Tab: Mô tả · Hướng dẫn sử dụng · Dùng cho lễ nào (link tới `/le/...`).
- Sản phẩm liên quan (carousel).

### 4.6 Giỏ hàng `/gio-hang`
- Danh sách dòng: ảnh nhỏ, tên, đơn giá, stepper, thành tiền, xoá.
- Tóm tắt: tạm tính, phí giao (ước tính), tổng; nút `Tiến hành thanh toán`.
- Giỏ trống: minh hoạ + nút `Xem cửa hàng`.
- Chưa đăng nhập bấm thanh toán → chuyển `/dang-nhap?redirect=/thanh-toan`.

### 4.7 Thanh toán `/thanh-toan`
Wizard 1 trang 3 khối (mobile xếp dọc, desktop 2 cột với tóm tắt đơn bên phải):
1. **Địa chỉ giao**: chọn từ sổ địa chỉ hoặc thêm mới (Họ tên, SĐT, Tỉnh/Thành, Quận/Huyện, Phường/Xã, Địa chỉ cụ thể).
2. **Thời gian giao**: chọn ngày + khung giờ (Sáng 7–11h / Chiều 13–17h / Tối 18–21h); hiển thị gợi ý "Giao trước ngày lễ …" nếu giỏ có bộ lễ.
3. **Thanh toán**: Thanh toán khi nhận hàng (COD) (MVP); ghi chú đơn.
- Nút `Đặt hàng` → trạng thái đang xử lý → chuyển trang **Đặt hàng thành công** (mã đơn, tóm tắt, nút `Xem đơn`).

### 4.8 Lịch sử đơn `/don-hang` & chi tiết `/don-hang/:id`
- Danh sách thẻ: mã đơn, ngày đặt, badge trạng thái (màu theo token), tổng tiền, nút `Xem`, `Mua lại`.
- Chi tiết: **timeline trạng thái** ngang/dọc, danh sách sản phẩm (snapshot), địa chỉ, thời gian giao, nút `Huỷ đơn` (chỉ khi Chờ xác nhận, có hộp xác nhận).

### 4.9 Ngày giỗ của tôi `/ngay-gio`
- Danh sách thẻ người thân: tên, quan hệ, ngày giỗ âm lịch, **ngày giỗ tới (dương lịch)**, đếm ngược.
- Nút `Thêm người thân` → modal form: Họ tên, Quan hệ (select), Ngày mất (chọn ngày + tháng âm; năm tuỳ chọn), Ghi chú.
- Mỗi thẻ: `Sửa`, `Xoá`, `Chuẩn bị đồ giỗ` (link tới giỏ/combo giỗ).

### 4.10 Hồ sơ `/ho-so` (tab)
- **Thông tin**: họ tên, SĐT, email (chỉ đọc), vùng miền mặc định.
- **Địa chỉ**: danh sách + đặt mặc định.
- **Nhắc lịch**: bật/tắt, nhắc trước 1/2/3 ngày, kênh email.
- **Bảo mật**: đổi mật khẩu.

### 4.11 Xác thực
- `/dang-nhap`: email, mật khẩu (hiện/ẩn), `Quên mật khẩu?`, nút `Đăng nhập`, nút `Tiếp tục với Google`, link `Đăng ký`.
- `/dang-ky`: họ tên, email, mật khẩu (≥ 8 ký tự), nhập lại, đồng ý điều khoản, chọn vùng miền (tuỳ chọn).
- Thông báo lỗi dưới từng ô; lỗi chung hiển thị banner trên form.
- Sau đăng ký: màn "Kiểm tra email để xác thực".
- `redirect` query: quay lại trang trước khi đăng nhập.

### 4.12 Hướng dẫn `/huong-dan`
- Lưới bài viết (ảnh, tiêu đề, tóm tắt, nhãn lễ + vùng). Trang bài: nội dung markdown, mục lục, bài liên quan, CTA "Mua đồ cho lễ này".

---

## 5. Component thư viện (cần dựng)

| Component | Props chính | Ghi chú |
|---|---|---|
| `Button` | variant: primary/outline/ghost/danger, size, loading | Có trạng thái disabled/loading |
| `Input`, `Select`, `Textarea`, `Checkbox`, `Stepper` | label, error, hint | Nhãn luôn hiển thị |
| `Badge` | tone: default/success/warning/danger/region-* | |
| `Card` | – | Bo 12px, bóng nhẹ |
| `Modal`, `Drawer`, `BottomSheet` | open, onClose | Khoá cuộn nền, đóng bằng Esc |
| `Toast` | type, message | 4s tự tắt |
| `Skeleton` | – | Dùng cho loading |
| `EmptyState` | icon, title, action | |
| `RegionSwitcher` | value, onChange | |
| `CalendarGrid` | month, year, events, onSelect | Hiển thị cả lịch âm |
| `DayCell` | solarDate, lunarLabel, markers | |
| `HolidayCard` | holiday, daysLeft | |
| `ChecklistItem` | item, checked, onToggle | |
| `ProductCard`, `ProductGallery` | product | |
| `CartLine`, `OrderSummary` | | |
| `OrderStatusTimeline` | status | |
| `AddressForm`, `AddressCard` | | |
| `AuthForm` | mode | |
| `Breadcrumb`, `Pagination` | | |

---

## 6. Trạng thái đơn hàng – ánh xạ giao diện
| Trạng thái | Nhãn | Màu badge |
|---|---|---|
| `pending` | Chờ xác nhận | warning |
| `confirmed` | Đã xác nhận | primary |
| `preparing` | Đang chuẩn bị | accent |
| `shipping` | Đang giao | region-bac (xanh dương) |
| `completed` | Hoàn thành | success |
| `cancelled` | Đã huỷ | danger |

---

## 7. Hành vi & hoạt hoạ
- Chuyển trang: fade 150ms. Hover thẻ: nâng nhẹ 2px.
- Thêm vào giỏ: toast "Đã thêm vào giỏ" + badge giỏ nảy nhẹ.
- Tôn trọng `prefers-reduced-motion` (tắt hoạt hoạ).
- Skeleton thay spinner khi tải danh sách.

## 8. Khả năng truy cập (a11y)
- Điều hướng bàn phím đầy đủ, focus ring rõ (`outline 2px accent`).
- `aria-label` cho nút icon; `role="grid"` cho lịch, ô có `aria-label` "Thứ Hai, 16/10/2026, âm 6/9, Rằm…".
- Form: label gắn `htmlFor`, lỗi `aria-describedby`.
- Không truyền đạt thông tin chỉ bằng màu (kèm chữ/icon).

## 9. Responsive
| Breakpoint | Rộng | Thay đổi |
|---|---|---|
| mobile | < 640 | 1 cột, bottom nav, lưới SP 2 cột |
| tablet | 640–1023 | lưới SP 3 cột, sidebar thu gọn |
| desktop | ≥ 1024 | header đầy đủ, 2 cột ở chi tiết lễ/thanh toán |

## 10. Nội dung mẫu cho UI (copy)
- Rỗng giỏ: "Giỏ hàng của bạn đang trống."
- Chưa có ngày giỗ: "Bạn chưa thêm ngày giỗ nào. Thêm để được nhắc đúng ngày."
- Lưu ý phong tục: "Cách cúng có thể khác nhau tuỳ vùng và gia đình. Bạn có thể điều chỉnh cho phù hợp."
- Lỗi chung: "Có lỗi xảy ra, vui lòng thử lại."

## 11. Tiêu chí nghiệm thu giao diện
- [ ] Đủ tất cả route mục 3, hiển thị đúng ở 360px/768px/1280px.
- [ ] Dùng token màu/chữ, không hard-code.
- [ ] Mỗi trang có loading/empty/error.
- [ ] Region Switcher hoạt động trên Lịch, Chi tiết lễ, Cửa hàng.
- [ ] Lighthouse a11y ≥ 90, không lỗi tương phản.
